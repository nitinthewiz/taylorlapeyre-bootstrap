# TODO

1. take out `<link>`s in leu of `@import`s in style.css
2. make styles for single.php and page.php in style.css