  <footer class="row">
    <div class="well">
      <p class="muted">You should follow me on twitter <a href="http://www.twitter.com/taylorlapeyre">here</a></p>
      <p class="muted">© Taylor Lapeyre 2012</p>
    </div>
  </footer>


  
  <!-- js files -->
  <script src="http://code.jquery.com/jquery-latest.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <!-- /js files -->
</body>
</html>